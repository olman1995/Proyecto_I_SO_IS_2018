# Proyecto_I_SO_IS_2018

En este proyecto se elabora un sistema cliente servidor con el uso de sockets en C